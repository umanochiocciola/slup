mkdir /usr/slup

cp dot_slup/* /usr/slup
cp code/slup.py /usr/slup
cp code/slup /usr/bin
chmod +x /usr/bin/slup
