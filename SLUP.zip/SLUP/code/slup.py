from os import popen, system
from sys import argv


def install(name):
    system(f'wget https://github.com/umanochiocciola/slup/raw/main/{name}.slup')
     
    CHK=popen(f'Rslup install {name}').read()
    
    print(CHK); return 1

    try:
        CHK = CHK.split('////////')[1]
        
        try:

            if CHK[:22] == 'Unresolved dependency:':
                Dname = CHK.split(' ')[1]
                install(Dname)
                return 0
        
        except:
            done = 1
        
    except:
        dove = 1
    
    
    if done:
        print(CHK)
        return 1

def remove(name):
    system(f'Rslup remove {name}')

try:
    action = argv[1]
    name = argv[2]
except:
    print('insufficent arguments'); exit(1)

try:
    action = eval(action)
except:
    print('invalid action argument'); exit(1)

done = 0
while not done:
    done = action(name)