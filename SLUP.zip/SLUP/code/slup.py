from os import popen, path, system
from sys import argv


def install(name):
    if not MainCollected:
        print('collecting', name)
        system(f'wget https://github.com/umanochiocciola/slup/raw/main/{name}.slup 2>/dev/null 1>&2')
        if not path.exists(name+'.slup'):
            print('unable to find', name); return 1
     
    CHK=popen(f'Rslup install {name}').read()

    done = 0
    try:
        CHK = CHK.split('////////')[1].strip('\n').strip(' ')
        #print('#####################  ', repr(CHK))
        
        try:

            if CHK[:22] == 'Unresolved dependency:':
                Dname = CHK.split(' ')[2]
                print('[resolving dependency] ', Dname)
                install(Dname)
                return 0
        
        except:0
        
    except:0
    
    print(CHK)
    
    return 1

def remove(name):
    CHK = popen(f'Rslup remove {name}').read()
    
    if '////////' in CHK:
        print(CHK.split('////////')[1].strip('\n').strip(' '))
    
    print(CHK)
    return 1

try:
    action = argv[1]
    name = argv[2]
except:
    print('insufficent arguments'); exit(1)

try:
    action = eval(action)
except:
    print('invalid action argument'); exit(1)

done = 0
MainCollected = 0
while not done:
    done = action(name)
    if not MainCollected: MainCollected = 1
    print('---------------------------',done)