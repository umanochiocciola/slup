from sys import argv
from os import path, system
import json

def main(action, slupfile, *garbage):

    if action == 'install':
        install(slupfile)

def GetInstalled():
    with open("/usr/slup/installed_slups", 'r') as f:
        installed = json.loads(f.read())
    
    return installed

def addInstalled(desc):
    with open("/usr/slup/installed_slups", 'r') as f:
        installed = json.loads(f.read())
    
    installed.append(desc)
    
    with open("/usr/slup/installed_slups", 'w') as f:
        f.write(json.dumps(installed))


def removeInstalled(desc):
    with open("/usr/slup/installed_slups", 'r') as f:
        installed = json.loads(f.read())
    
    installed.remove(desc)
    
    with open("/usr/slup/installed_slups", 'w') as f:
        f.write(json.dumps(installed))



def install(slupfile):
    slupfile = slupfile+'.slup'
    
    if not path.exists(slupfile):
        error('given slupfile doesn\'t exist')

    system(f'unzip {slupfile}')
    slup_path = path.abspath(''.join(slupfile.split('.')[:-1]))
    
    try:
        with open(f"{slup_path}/descriptor", 'r') as f:
            descriptor = json.loads(f.read())
    except Exception as e:
        error('Invalid or missing descriptor (', e, ')')
    
    
    try:
        installed = GetInstalled()
        MinInst = [{'name': i['name'], 'version': i['version']} for i in installed]
        
        for i in descriptor["dependencies"]:
            if not i in MinInst:
                error("Unresolved dependency:", i["name"], 'version', i["version"])


        ThereAreAssets = descriptor.get('assets', 0)
        
        if ThereAreAssets:
            system(f'mkdir /usr/slups/{descriptor["name"]}')
            system(f'mv -r "{slup_path}/{descriptor["assets"]}/*" /usr/slups/{descriptor["name"]}')
        else:
            print('(This slup has no assets)')
        
        system(f'mv "{slup_path}/{descriptor["execute"]}" /usr/bin')
        system(f'chmod +x /usr/bin/{descriptor["execute"]}')

        addInstalled(descriptor)
        
    except Exception as e:
        error("Invalid package descriptor (", e, ')')
    
    
    try:
        with open(f'{slup_path}/readme', 'r') as f:
            readme = f.read()
    except:
        readme = ''
    
    system(f'rm -r {slup_path}')
    
    print('\n -----', readme, '-----\n')
    print('Done!')


def remove(slupname):
    installed = GetInstalled()
    
    for i in installed:
        if i['name'] == slupname:
            
            slup = i
            break
    
        else:
            error('given slup is not installed')
    
    
    ThereAreAssets = descriptor.get('assets', 0)
    
    system(f'rm /usr/bin/{slup["execute"]}')
    if ThereAreAssets:
        system(f'rm /usr/slups/{slup["name"]}')
    
    removeInstalled(slup)
    print(f'{slup["name"]} succesfully removed')
    

def error(*msg):
    print('////////')
    print(*msg)
    exit(1)




if len(argv) < 3:
    error("insufficient arguments")

if __name__ == "__main__":
    main(*argv[1:])
